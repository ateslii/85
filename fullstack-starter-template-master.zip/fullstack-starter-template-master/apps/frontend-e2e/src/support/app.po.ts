export const getGreeting = () => cy.get('h1');
