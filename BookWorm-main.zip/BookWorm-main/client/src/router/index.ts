export { RouterMain } from './components/RouterMain'
export { Pages } from './config'
export type { RouteType } from './types/router.types'
